import pandas as pd
df = pd.read_csv('10K findings.csv')
# First calculate revenue growth if not done
df['Revenue Growth (%)'] = df.groupby('Company')['Total Revenue'].pct_change() * 100

# Now display the selected columns
revenue_growth=df[['Company', 'Year', 'Revenue Growth (%)']]

revenue_growth
# First calculate Net Income growth if not done
df['Net Income Growth (%)'] = df.groupby(['Company'])['Net Income'].pct_change() * 100

# Now display the selected columns
net_income = df[['Company', 'Year', 'Net Income Growth (%)']]

net_income
company_summary = df.groupby('Company')[['Total Revenue', 'Net Income']].sum().sort_values(by='Total Revenue', ascending=False)
company_summary

yearly_summary = df.groupby(['Year', 'Company'])[['Total Revenue', 'Net Income']].sum().reset_index()
yearly_summary

avg_metrics = df.groupby('Company')[['Total Revenue', 'Net Income', 'Revenue Growth (%)', 'Net Income Growth (%)']].mean()
avg_metrics

max_growth = df.groupby('Company')[['Revenue Growth (%)', 'Net Income Growth (%)']].max()
max_growth


min_growth = df.groupby('Company')[['Revenue Growth (%)', 'Net Income Growth (%)']].min()
min_growth

import pandas as pd

# Load the data from the Excel spreadsheet
file_path = '10K findings.csv'
df = pd.read_csv(file_path)

# Calculate year-over-year growth rates for Total Revenue and Net Income
df['Revenue Growth (%)'] = df.groupby('Company')['Total Revenue'].pct_change() * 100
df['Net Income Growth (%)'] = df.groupby('Company')['Net Income'].pct_change() * 100

# Fill NA values that result from pct_change calculations with 0 or an appropriate value
df.fillna(0, inplace=True)

# Display the dataframe to verify the calculations
print(df)

# Optionally, you could summarize these findings for each company
summary = df.groupby('Company').agg({
    'Revenue Growth (%)': 'mean',
    'Net Income Growth (%)': 'mean'
}).reset_index()

print("\nYear-over-Year Average Growth Rates (%):")
print(summary)
## Summary of Financial Analysis

### Methodology:
We grouped financial data by Company and Year to observe total revenue and net income trends. Growth rates were calculated using the `pct_change()` function.

Financial Growth Summary (YoY)
Key Highlights by Company:
Apple
Revenue Growth: Slight overall decline of -0.68% YoY.

Net Income Growth: Small positive growth of 2.12%, showing stable profitability.

Insight: Despite a dip in revenue in 2022, Apple maintained profitability with improving net income, indicating efficient cost control and strong margins.

Microsoft
Revenue Growth: Average decline of -6.66% YoY.

Net Income Growth: Decrease of -5.79%, reflecting modestly shrinking profits.

Insight: Microsoft saw a downward trend in both revenue and net income, possibly due to market saturation or increased operational costs.

Tesla
Revenue Growth: Decline of -5.59% YoY, though not drastic.

Net Income Growth: Impressive increase of 31.13%, driven by major improvements from 2023.

Insight: Tesla’s surge in net income despite lower revenue suggests operational efficiency or increased profit margins—potentially from cost-saving innovations or premium pricing.

Overall Observations
Tesla is the most improved in terms of profitability.

Apple remains stable, balancing minor revenue dips with income growth.

Microsoft experienced the steepest decline in both revenue and income, warranting further investigation.
import pandas as pd

# Load the cleaned financial data with year-over-year growth
data = {
    'Company': ['Microsoft', 'Microsoft', 'Microsoft', 'Tesla', 'Tesla', 'Tesla', 'Apple', 'Apple', 'Apple'],
    'Year': [2024, 2023, 2022, 2024, 2023, 2022, 2024, 2023, 2022],
    'Total Revenue': [245122, 211915, 198270, 97690, 96773, 81462, 7700000000, 8200000000, 7500000000],
    'Net Income': [88136, 72361, 72738, 7153, 14974, 12587, 93736, 96995, 99803],
    'Revenue Growth (%)': [0.000, -13.547, -6.439, 0.000, -0.939, -15.822, 0.000, 6.494, -8.537],
    'Net Income Growth (%)': [0.000, -17.898, 0.521, 0.000, 109.339, -15.941, 0.000, 3.477, 2.895]
}

df = pd.DataFrame(data)

# Calculate values to use in chatbot responses
latest_revenue = df[df['Year'] == 2024][['Company', 'Total Revenue']].set_index('Company').to_dict()['Total Revenue']
latest_net_income = df[df['Year'] == 2024][['Company', 'Net Income']].set_index('Company').to_dict()['Net Income']
revenue_growth = df[df['Year'] == 2023][['Company', 'Revenue Growth (%)']].set_index('Company').to_dict()['Revenue Growth (%)']
net_income_growth = df[df['Year'] == 2023][['Company', 'Net Income Growth (%)']].set_index('Company').to_dict()['Net Income Growth (%)']

latest_revenue, latest_net_income, revenue_growth, net_income_growth

def simple_chatbot(company, user_query):
    company = company.title()
    
    if company not in latest_revenue:
        return "Sorry, I don't have data for that company."

    if user_query == "What is the total revenue?":
        return f"{company}'s total revenue in 2024 was ${latest_revenue[company]:,}."
    elif user_query == "What is the net income?":
        return f"{company}'s net income in 2024 was ${latest_net_income[company]:,}."
    elif user_query == "How has revenue changed over the last year?":
        return f"{company}'s revenue changed by {revenue_growth[company]:.2f}% from 2022 to 2023."
    elif user_query == "How has net income changed over the last year?":
        return f"{company}'s net income changed by {net_income_growth[company]:.2f}% from 2022 to 2023."
    else:
        return "Sorry, I can only provide information on predefined queries."

def ask_bot():
    company = input("Enter company: ")
    question = input("Your question: ")
    print(simple_chatbot(company, question))
ask_bot()


